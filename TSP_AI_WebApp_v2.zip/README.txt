
TSP AI WebApp (Flask) - Ready to run
-----------------------------------
1. Create virtual environment (optional)
   python -m venv venv
   venv\Scripts\activate   (Windows) or source venv/bin/activate (mac/linux)
2. Install requirements:
   python -m pip install -r requirements.txt
3. Run app:
   python app.py
   (The browser should open automatically at http://127.0.0.1:5000)
Login credentials: admin / 123
