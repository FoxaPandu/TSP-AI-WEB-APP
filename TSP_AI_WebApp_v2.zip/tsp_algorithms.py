
import math, random, time
def euclidean(a,b):
    return math.hypot(a[0]-b[0], a[1]-b[1])

def total_distance(tour, coords):
    return sum(euclidean(coords[tour[i]], coords[tour[(i+1)%len(tour)]]) for i in range(len(tour)))

def nearest_neighbor(coords, start=0):
    n = len(coords)
    unvisited = set(range(n))
    tour = [start]
    unvisited.remove(start)
    current = start
    while unvisited:
        nxt = min(unvisited, key=lambda x: euclidean(coords[current], coords[x]))
        tour.append(nxt)
        unvisited.remove(nxt)
        current = nxt
    return tour, total_distance(tour, coords)

def two_opt(coords, tour=None):
    n = len(coords)
    if tour is None:
        tour = list(range(n))
    best = tour[:]
    best_cost = total_distance(best, coords)
    improved = True
    while improved:
        improved = False
        for i in range(1, n-1):
            for j in range(i+1, n):
                if j - i == 1: continue
                new_tour = best[:i] + best[i:j][::-1] + best[j:]
                new_cost = total_distance(new_tour, coords)
                if new_cost + 1e-12 < best_cost:
                    best = new_tour
                    best_cost = new_cost
                    improved = True
    return best, best_cost

def simulated_annealing(coords, initial_tour=None, t0=500.0, alpha=0.995, min_temp=1e-3, iter_per_temp=100):
    n = len(coords)
    if initial_tour is None:
        initial_tour, _ = nearest_neighbor(coords)
    best_tour = initial_tour[:]
    best_cost = total_distance(best_tour, coords)
    cur_tour = best_tour[:]
    cur_cost = best_cost
    T = t0
    while T > min_temp:
        for _ in range(iter_per_temp):
            i, j = sorted(random.sample(range(1, n), 2))
            candidate = cur_tour[:i] + cur_tour[i:j+1][::-1] + cur_tour[j+1:]
            candidate_cost = total_distance(candidate, coords)
            delta = candidate_cost - cur_cost
            if delta < 0 or random.random() < math.exp(-delta / T):
                cur_tour = candidate
                cur_cost = candidate_cost
                if cur_cost < best_cost:
                    best_cost = cur_cost
                    best_tour = cur_tour[:]
        T *= alpha
    return best_tour, best_cost

def genetic_algorithm(coords, pop_size=50, generations=150, mutation_prob=0.05):
    n = len(coords)
    population = []
    for _ in range(pop_size):
        t = list(range(n))
        random.shuffle(t)
        population.append(t)
    def fitness(tour):
        return 1.0 / (1e-9 + total_distance(tour, coords))
    for _ in range(generations):
        population = sorted(population, key=lambda t: total_distance(t, coords))
        elite = population[:max(1, pop_size//10)]
        new_pop = elite[:]
        weights = [fitness(t) for t in population]
        total_w = sum(weights)
        probs = [w/total_w for w in weights] if total_w>0 else [1/len(weights)]*len(weights)
        while len(new_pop) < pop_size:
            p1 = random.choices(population, weights=probs, k=1)[0]
            p2 = random.choices(population, weights=probs, k=1)[0]
            a,b = sorted(random.sample(range(n),2))
            child = [-1]*n
            child[a:b+1] = p1[a:b+1]
            p2i = 0
            for i in range(n):
                if child[i] == -1:
                    while p2[p2i] in child:
                        p2i += 1
                    child[i] = p2[p2i]
            if random.random() < mutation_prob:
                i,j = random.sample(range(n),2)
                child[i], child[j] = child[j], child[i]
            new_pop.append(child)
        population = new_pop
    best = min(population, key=lambda t: total_distance(t, coords))
    return best, total_distance(best, coords)
