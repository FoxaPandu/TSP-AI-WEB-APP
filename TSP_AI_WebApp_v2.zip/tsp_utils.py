
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
from typing import List, Tuple
from tsp_algorithms import total_distance

def save_route_plot(coords, tour, filepath):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    x = [coords[i][0] for i in tour] + [coords[tour[0]][0]]
    y = [coords[i][1] for i in tour] + [coords[tour[0]][1]]
    plt.figure(figsize=(6,5))
    plt.plot(x, y, 'o-', linewidth=1.5)
    for i,(xx,yy) in enumerate(coords):
        plt.text(xx+0.5, yy+0.5, str(i), fontsize=9)
    plt.title(f'TSP route (cost = {total_distance(tour, coords):.3f})')
    plt.xlabel('X'); plt.ylabel('Y'); plt.grid(True); plt.tight_layout()
    plt.savefig(filepath)
    plt.close()
    return filepath
