
from flask import Flask, render_template, request, redirect, session, url_for, send_from_directory, flash
import sqlite3, os, time, json, random, csv, hashlib, webbrowser
from tsp_algorithms import nearest_neighbor, two_opt, simulated_annealing, genetic_algorithm
from tsp_utils import save_route_plot

APP_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(APP_DIR, 'database.db')
STATIC_OUT = os.path.join(APP_DIR, 'static', 'outputs')

app = Flask(__name__)
app.secret_key = 'replace_this_with_a_random_secret'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(stored, entered):
    return stored == hash_password(entered)

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.executescript('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS problems (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        name TEXT,
        coords TEXT,
        created_at TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS solutions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problem_id INTEGER,
        algorithm TEXT,
        route TEXT,
        cost REAL,
        time_taken REAL,
        image TEXT,
        created_at TEXT,
        FOREIGN KEY(problem_id) REFERENCES problems(id)
    );
    ''')
    conn.commit()

    # add sample user and problem if missing
    cur.execute('SELECT * FROM users WHERE username=?', ('admin',))
    if not cur.fetchone():
        cur.execute('INSERT INTO users (username,password) VALUES (?,?)', ('admin', hash_password('123')))
        conn.commit()
    cur.execute('SELECT * FROM problems')
    if not cur.fetchone():
        sample = [[random.randint(0,100), random.randint(0,100)] for _ in range(6)]
        cur.execute('INSERT INTO problems (user_id,name,coords,created_at) VALUES (?,?,?,?)', (1,'Sample Problem', json.dumps(sample), time.ctime()))
        conn.commit()
    conn.close()

@app.route('/')
def home():
    conn = get_db()
    probs = conn.execute('SELECT p.id, p.name, p.coords, u.username, p.created_at FROM problems p LEFT JOIN users u ON p.user_id=u.id ORDER BY p.id DESC').fetchall()
    conn.close()
    return render_template('home.html', problems=probs, user=session.get('user'))

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method=='POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        if not username or not password:
            flash('Provide username and password')
            return redirect(url_for('signup'))
        conn = get_db()
        try:
            conn.execute('INSERT INTO users (username, password) VALUES (?,?)', (username, hash_password(password)))
            conn.commit()
            flash('Signup successful. Please login.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists')
        finally:
            conn.close()
    return render_template('signup.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        conn.close()
        if user and verify_password(user['password'], password):
            session['user'] = {'id': user['id'], 'username': user['username']}
            return redirect(url_for('home'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))

@app.route('/submit', methods=['GET','POST'])
def submit():
    if 'user' not in session:
        flash('Login required'); return redirect(url_for('login'))
    if request.method=='POST':
        name = request.form.get('name') or 'Problem'
        coords_text = request.form.get('coords')
        try:
            coords = json.loads(coords_text)
            if not isinstance(coords, list) or len(coords)<3:
                flash('Provide valid JSON coords with at least 3 points'); return redirect(url_for('submit'))
        except Exception:
            flash('Invalid coords JSON'); return redirect(url_for('submit'))
        conn = get_db()
        conn.execute('INSERT INTO problems (user_id,name,coords,created_at) VALUES (?,?,?,?)', (session['user']['id'], name, json.dumps(coords), time.ctime()))
        conn.commit(); conn.close()
        flash('Problem saved'); return redirect(url_for('home'))
    sample = [[round(random.random()*100,3), round(random.random()*100,3)] for _ in range(8)]
    return render_template('submit.html', sample=json.dumps(sample))

@app.route('/problem/<int:pid>')
def problem_view(pid):
    conn = get_db()
    p = conn.execute('SELECT * FROM problems WHERE id=?', (pid,)).fetchone()
    sols = conn.execute('SELECT * FROM solutions WHERE problem_id=? ORDER BY id DESC', (pid,)).fetchall()
    conn.close()
    if not p: return 'Problem not found', 404
    coords = json.loads(p['coords'])
    return render_template('problem.html', problem=p, coords=coords, solutions=sols, user=session.get('user'))

@app.route('/solve/<int:pid>', methods=['POST'])
def solve(pid):
    if 'user' not in session:
        flash('Login required'); return redirect(url_for('login'))

    algo = request.form.get('algorithm')
    conn = get_db()
    p = conn.execute('SELECT * FROM problems WHERE id=?', (pid,)).fetchone()

    if not p:
        conn.close(); flash('Problem not found'); return redirect(url_for('home'))

    coords = json.loads(p['coords'])
    start_time = time.time()

    if algo == 'Nearest Neighbor':
        route, cost = nearest_neighbor(coords)
    elif algo == '2-Opt':
        nn_tour, _ = nearest_neighbor(coords)
        route, cost = two_opt(coords, nn_tour)
    elif algo == 'Simulated Annealing':
        nn_tour, _ = nearest_neighbor(coords)
        route, cost = simulated_annealing(coords, initial_tour=nn_tour)
    elif algo == 'Genetic':
        route, cost = genetic_algorithm(coords)
    else:
        route, cost = nearest_neighbor(coords)

    time_taken = round(time.time() - start_time, 3)
    os.makedirs(STATIC_OUT, exist_ok=True)
    img_name = f"problem_{pid}_{algo.replace(' ', '_')}_{int(time.time())}.png"
    img_path = os.path.join(STATIC_OUT, img_name)
    save_route_plot(coords, route, img_path)
    web_path = f"static/outputs/{img_name}"

    conn.execute('INSERT INTO solutions (problem_id, algorithm, route, cost, time_taken, image, created_at) VALUES (?,?,?,?,?,?,?)',
                 (pid, algo, json.dumps(route), cost, time_taken, web_path, time.ctime()))
    conn.commit(); conn.close()

    flash(f"{algo} solution added (cost={cost:.2f})")
    return redirect(url_for('problem_view', pid=pid))

@app.route('/export/solutions')
def export_solutions():
    conn = get_db()
    rows = conn.execute('SELECT * FROM solutions').fetchall()
    conn.close()
    os.makedirs(STATIC_OUT, exist_ok=True)
    out = os.path.join(STATIC_OUT, 'solutions.csv')
    with open(out, 'w', newline='') as f:
        w = csv.writer(f)
        if rows:
            w.writerow(rows[0].keys())
            for r in rows:
                w.writerow(r)
    return send_from_directory(STATIC_OUT, 'solutions.csv', as_attachment=True)

@app.route('/static/outputs/<path:filename>')
def static_outputs(filename):
    return send_from_directory(os.path.join(APP_DIR,'static','outputs'), filename)

if __name__ == '__main__':
    os.makedirs(STATIC_OUT, exist_ok=True)
    init_db()
    # auto-open browser
    try:
        webbrowser.open('http://127.0.0.1:5000')
    except Exception:
        pass
    app.run(debug=True)
